# Tamil Word Learner Android project

This is an Android Studio project wrapping the Tamil Word Learner interface in a WebView. The word lessons and interface are bundled locally, so the core app works offline. Browser/system Tamil speech availability may vary.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle to sync and install the Android SDK platform requested by the project (API 35).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the APK under `app/build/outputs/apk/debug/`.

This ZIP is the project source, not a precompiled APK. It has not been built or tested in Android Studio in this environment.
